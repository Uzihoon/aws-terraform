import json

print('Loading function')

def lambda_handler(event, context):
    
    print('Received event : ' + json.dumps(event, indent=2))
    
    name = 'world'
    if event['queryStringParameters'] is not None and 'name' in event['queryStringParameters']:
        name = event['queryStringParameters']['name']
    
    greeting = 'Hello ' + name + '!'
    print(greeting)
    
    result = {
        "greeting": greeting
    }
    
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }